<?php

class Controller {

	public function handleRequest(Request $req){
		$response = new Response;
		$view = new View('baseDesign');
		$glob = new Glob;

		$headerControlVars = array(
			"ClassName" => "header"
			);

		$pageControlVars = array(
			"ClassName" => "page"
			);

		$variables = array(
			"ToolBar" => $this->form("Toolbar"),
			"HeaderForm" => $this->form("HeaderControls", $headerControlVars),
			"PageForm" => $this->form("PageControls", $pageControlVars),
			"Title" => "Home",
			"Layout" => "twoColumn",
			"colOneWidth" => "two-thirds", // available widths = full, two-thirds, half, third, fourth.
			"colTwoWidth" => "third",
			"headerClass" => "header",
			"navClass" => "navigation",
			"contentClass" => "maincontent",
			"footerClass" => "footer",
			"colOneContent" => "homepageContent",
			"colTwoContent" => "videopageContent"
		);
		
		$response->setBody($view->render($variables));
		
		return $response;
	}

	public function form($template,$vars=array()) {
	    $view = new View($template);
	    return $view->render($vars);
	}

}
